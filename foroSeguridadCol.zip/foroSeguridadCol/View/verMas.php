<?php 

include_once ("../Partials/head.php");
include_once ("../Partials/menu.php");
//include_once ("../Partials/footer.php");

include_once ("../Model/conexion.php");

?>

    <div class="container">
        <div class="row">
            <h1 class="text-center text-danger">Foro seguridad Colombia</h1>
            <p class="mt-3 h3">Foro seguridad colombia es un proyecto,realizado con el proposito de que escribas algo que te sucedió , 
            alguna via en mal estado . Algún caso de inseguridad o lo que desees compartir , porfavor evita hacer spam(Escribir muchos sucesos).</p>
        </div>
    </div>

